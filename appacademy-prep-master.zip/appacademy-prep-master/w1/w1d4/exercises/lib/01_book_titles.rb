class Book
  # TODO: your code goes here!
end
