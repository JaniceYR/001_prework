def ftoc(fahrenheit)
  (fahrenheit - 32) * (5.0 / 9)
end

def ctof(celsius)
  (celsius * 9.0 / 5) + 32
end
