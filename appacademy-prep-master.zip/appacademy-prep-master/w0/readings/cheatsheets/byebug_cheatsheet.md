# Byebug Cheatsheet

Command   | Aliases  | Subcommands
----------|----------|------------
backtrace | bt where |
break     | b        |
continue  | c        |
disable   |          | breakpoints display
display   |          |
enable    |          | breakpoints display
help      | h        |
history   |          |
info      | i        | breakpoints display file line program
list      |          |
next      | n        |
quit      | q        |
step      | s        |
undisplay |          |
var       | v        | all constant global instance local
up        |          |
down      |          |
save      |          |
source    |          |
