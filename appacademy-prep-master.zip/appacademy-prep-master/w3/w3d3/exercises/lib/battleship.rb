class BattleshipGame
  attr_reader :board, :player
end
