class XmlDocument
  # TODO: your code goes here!
end
