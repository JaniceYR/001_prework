class ComputerPlayer
end
